import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.Vector;

public class Assignment {
	/*
//a/b//a
//a/b//a/b
	 */
	static int queries_length;
	static TreeSet res = new TreeSet<Integer>();
	static boolean last;
	static boolean match = false;
	static LinkedList<Integer>[] contexts;
	static int level; 
	public static void main(String[] args) throws IOException {
		FileInputStream file = new FileInputStream(args[0]);
		//FileInputStream file = new FileInputStream("/home/omcscn/Desktop/Lab3_FinalProject/wdm_project_test/input.txt");
		InputStreamReader ins = new InputStreamReader(file);
		BufferedReader in = new BufferedReader(ins);
		String xpathQuery = args[1]; 
		//String xpathQuery = "//a/a/a/b"; 
		String[] xpathTmp = xpathQuery.split("//");
		String[] queries = Arrays.copyOfRange(xpathTmp, 1, xpathTmp.length);
		String line = "";
		int p = -1;
		Stack st = new Stack();
		Stack preorder_stack = new Stack();
		int preorder =-1;

		while ((line = in.readLine()) != null) {
			String[] tmp = line.split(" ");
			if (tmp[0].equals("0")){
				++preorder;
				st.push(tmp[1]);
				preorder_stack.push(preorder);
				Object[] a = st.toArray();
				String[] text = new String[st.size()];
				int k = -1;
				for(Object o : a){
					text[++k] = o.toString();
				}
				contexts = new LinkedList[queries.length-1];
				for (int l = 0; l < queries.length-1; l++) {
					contexts[l] = new LinkedList();
				}	
				allMatcher(text, queries, preorder_stack);
			}
			if(tmp[0].equals("1")){
				if(!st.isEmpty()){
					st.pop();
					preorder_stack.pop();
				}
			}
		}
		for(Object r: res){
			System.out.println(r);
		}
	}

	private static void allMatcher(String[] text, String[] queries, Stack preorder_stack) {
		last = false;
		queries_length = queries.length;
		level = -1;
		LinkedList q = new LinkedList();

		for(String query : queries){
			int query_length = query.length();
			String[] subPattern = query.split("/");
			q.add(subPattern);
		}

		Iterator it = q.iterator();
		String[] subQuery = (String[]) it.next();
		level++;
		if(level==queries_length-1) last = true;
		kmpMatcher(text, subQuery, preorder_stack, last);
		if(match && it.hasNext()){
			recursiveCall(text, preorder_stack, it);
			}
		
	}

		private static void recursiveCall(String[] text, Stack preorder_stack,Iterator it) {
		
			String[] subQuery2 = (String[]) it.next();
			level++;
			if(level==queries_length-1) last = true;
			for(int context : contexts[level-1]){
				String[] suite_text = Arrays.copyOfRange(text, context+1, text.length);
				Stack sub_preorder_stack = new Stack();
				for(int k = context+1; k < preorder_stack.size(); k++){
					sub_preorder_stack.push(preorder_stack.elementAt(k));
				}
				kmpMatcher(suite_text, subQuery2, sub_preorder_stack, last);
				if(match && it.hasNext()) recursiveCall(suite_text, sub_preorder_stack, it);
			}
			level--;
			last = false;
	}

	public static int[] kmprefix(String[] pattern){
		int m = pattern.length;
		int[] prefix = new int[pattern.length];
		prefix[0] = -1;
		//ArrayList<Integer> prefix = new ArrayList<Integer>();
		int  i = -1;
		for (int j=1; j< m;j++){
			while(i>=0 && !pattern[i+1].equals(pattern[j]))
				i = prefix[i];
			if(pattern[i+1].equals(pattern[j]))
				i = i+1;
			prefix[j] = i;
		}
		return prefix;
	}

	public static void kmpMatcher(String[] text, String[] pattern, Stack preorder_stack, boolean last){
		int n = text.length;
		int m = pattern.length;
		int[] kmprefix = kmprefix(pattern);
		int  i = -1;
		match = false;
		for (int j=0; j< n;j++){
			while(i>=0 && !pattern[i+1].equals(text[j]))
				i = (int) kmprefix[i];
			if(pattern[i+1].equals(text[j]))
				i++;
			if(i==m-1){
				if(last)res.add(preorder_stack.elementAt(j));
				i = (int)kmprefix[i];
				match = true;
				
				if(!last)contexts[level].add(j);
			}
		}
	}
}
